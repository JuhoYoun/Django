from django.apps import AppConfig


class FoodsConfig(AppConfig):
    name = 'foods'
